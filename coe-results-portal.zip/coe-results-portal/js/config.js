// config.js - Secure configuration for TMRJC COE Portal
const CONFIG = {
    SHEET_ID: '1nGUuoKWQ3ZewgTWrafzJLjDkwSoT-ETMJ8OMhsl0IwM',
    BASE_URL: 'https://opensheet.elk.sh',
    
    get SHEET_URLS() {
        return {
            STUDENTS: `${this.BASE_URL}/${this.SHEET_ID}/Students`,
            RESULTS: `${this.BASE_URL}/${this.SHEET_ID}/Results`,
            ADMIN: `${this.BASE_URL}/${this.SHEET_ID}/Admin_Credentials`,
            ARCHIVES: `${this.BASE_URL}/${this.SHEET_ID}/Archives`
        };
    },
    
    // Column names - UPDATED to match Google Sheet exactly
    COLUMNS: {
        ROLL_NO: 'Roll No.',  // Has dot at the end
        STUDENT_NAME: 'Student Name',
        BATCH: 'Batch',
        YEAR: 'Year (1st/2nd)',
        PARENT_PHONE: 'Parent Phone',
        EMAIL: 'Email ID',
        PERCENTAGE: 'Percentage',
        TEST_NAME: 'Test Name',
        DATE: 'Date',
        BATCH_RANK: 'Batch Rank',
        COLLEGE_RANK: 'College Rank',
        TOTAL: 'Total',
        PHYSICS: 'Physics',
        CHEMISTRY: 'Chemistry',
        MATHS_BIOLOGY: 'Maths/Biology'
    },
    
    // Performance thresholds
    THRESHOLDS: {
        EXCELLENT: 90,
        GOOD: 80,
        AVERAGE: 70,
        NEEDS_IMPROVEMENT: 0
    },
    
    // Error messages
    ERRORS: {
        NO_DATA: 'No data available',
        NETWORK: 'Unable to connect to server. Check your internet connection.',
        STUDENT_NOT_FOUND: 'Student not found',
        NO_RESULTS: 'No test results available',
        SESSION_EXPIRED: 'Your session has expired. Please login again.',
        UNAUTHORIZED: 'Unauthorized access'
    },
    
    // Session management
    ADMIN_SESSION_KEY: 'coe_admin_session',
    SESSION_TIMEOUT: 30 * 60 * 1000, // 30 minutes in milliseconds
    
    // Security settings
    MAX_LOGIN_ATTEMPTS: 5,
    LOGIN_BLOCK_TIME: 15 * 60 * 1000, // 15 minutes
    CSRF_TOKEN_KEY: 'coe_csrf_token'
};

// Secure utility functions with XSS protection
const UTILS = {
    // Safely get column value
    getColumn(row, columnName) {
        if (!row || !columnName) return '';
        return row[columnName] || '';
    },
    
    // Parse percentage safely
    parsePercentage(percentageStr) {
        if (!percentageStr) return 0;
        try {
            const clean = percentageStr.toString().replace('%', '').trim();
            const parsed = parseFloat(clean);
            return isNaN(parsed) ? 0 : Math.min(Math.max(parsed, 0), 100);
        } catch (e) {
            console.error('Error parsing percentage:', e);
            return 0;
        }
    },
    
    // Format date safely
    formatDate(dateString) {
        if (!dateString) return 'N/A';
        try {
            const date = new Date(dateString);
            if (isNaN(date.getTime())) return dateString;
            
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        } catch (e) {
            console.error('Error formatting date:', e);
            return dateString;
        }
    },
    
    // Get performance badge
    getPerformanceBadge(score) {
        if (score >= CONFIG.THRESHOLDS.EXCELLENT) {
            return { text: 'Excellent', class: 'badge-excellent' };
        } else if (score >= CONFIG.THRESHOLDS.GOOD) {
            return { text: 'Good', class: 'badge-good' };
        } else if (score >= CONFIG.THRESHOLDS.AVERAGE) {
            return { text: 'Average', class: 'badge-average' };
        } else {
            return { text: 'Needs Improvement', class: 'badge-improving' };
        }
    },
    
    // Create elements safely (XSS protection)
createElement(type, attributes = {}, textContent = '') {
    const element = document.createElement(type);
    
    // Set attributes safely
    Object.keys(attributes).forEach(key => {
        if (key.startsWith('on')) {
            // Allow onclick for now since we need it
            // In production, use addEventListener instead
            element.setAttribute(key, attributes[key]);
            return;
        }
        element.setAttribute(key, attributes[key]);
    });
    
    // Set text content safely (not innerHTML)
    if (textContent) {
        element.textContent = textContent;
    }
    
    return element;
},
    
    // Create safe HTML string (for trusted content only)
    createSafeHTML(htmlString) {
        const div = document.createElement('div');
        div.textContent = ''; // Clear any content
        return div.innerHTML; // This escapes HTML
    },
    
    // Loading spinner
    createLoadingSpinner(message = 'Loading...') {
        const div = this.createElement('div', { class: 'loading-spinner' });
        const icon = this.createElement('i', { class: 'fas fa-spinner spinner' });
        const p = this.createElement('p', {}, message);
        
        div.appendChild(icon);
        div.appendChild(p);
        return div;
    },
    
    // Error message
    createErrorMessage(message, icon = 'exclamation-triangle') {
        const div = this.createElement('div', { class: 'error-message' });
        const iconEl = this.createElement('i', { class: `fas fa-${icon}` });
        const p = this.createElement('p', {}, message);
        const button = this.createElement('button', {
            style: 'margin-top: 10px; padding: 8px 16px; background: var(--primary-color); color: white; border: none; border-radius: 5px; cursor: pointer;'
        }, 'Retry');
        
        button.onclick = () => location.reload();
        
        div.appendChild(iconEl);
        div.appendChild(p);
        div.appendChild(button);
        return div;
    },
    
    // Empty state
    createEmptyState(message, icon = 'search') {
        const div = this.createElement('div', { class: 'empty-state' });
        const iconEl = this.createElement('i', { class: `fas fa-${icon}` });
        const p = this.createElement('p', {}, message);
        
        div.appendChild(iconEl);
        div.appendChild(p);
        return div;
    },
    
    // Secure session management
    generateCSRFToken() {
        const token = Array.from(crypto.getRandomValues(new Uint8Array(32)))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');
        sessionStorage.setItem(CONFIG.CSRF_TOKEN_KEY, token);
        return token;
    },
    
    validateCSRFToken(token) {
        const storedToken = sessionStorage.getItem(CONFIG.CSRF_TOKEN_KEY);
        return storedToken && storedToken === token;
    },
    
    validateAdminSession() {
        try {
            const session = localStorage.getItem(CONFIG.ADMIN_SESSION_KEY);
            if (!session) return false;
            
            const sessionData = JSON.parse(session);
            const now = new Date().getTime();
            
            // Validate all required fields
            if (!sessionData.username || !sessionData.loggedIn || !sessionData.expires) {
                this.clearAdminSession();
                return false;
            }
            
            // Check if session is expired
            if (sessionData.expires <= now) {
                this.clearAdminSession();
                return false;
            }
            
            // Verify session integrity
            if (sessionData.expires - sessionData.timestamp !== CONFIG.SESSION_TIMEOUT) {
                this.clearAdminSession();
                return false;
            }
            
            return true;
        } catch (e) {
            console.error('Session validation error:', e);
            this.clearAdminSession();
            return false;
        }
    },
    
    setAdminSession(username, role = 'Staff') {
        try {
            const timestamp = new Date().getTime();
            const session = {
                username: this.createSafeHTML(username),
                role: this.createSafeHTML(role),
                loggedIn: true,
                timestamp: timestamp,
                expires: timestamp + CONFIG.SESSION_TIMEOUT,
                sessionId: this.generateCSRFToken(),
                userAgent: navigator.userAgent,
                ipHash: '' // Would be set by server in production
            };
            
            localStorage.setItem(CONFIG.ADMIN_SESSION_KEY, JSON.stringify(session));
        } catch (e) {
            console.error('Error setting session:', e);
        }
    },
    
    clearAdminSession() {
        try {
            localStorage.removeItem(CONFIG.ADMIN_SESSION_KEY);
            sessionStorage.removeItem(CONFIG.CSRF_TOKEN_KEY);
        } catch (e) {
            console.error('Error clearing session:', e);
        }
    },
    
    // Data validation
    validateStudentData(student) {
        if (!student) return false;
        
        const requiredFields = [
            CONFIG.COLUMNS.ROLL_NO,
            CONFIG.COLUMNS.STUDENT_NAME,
            CONFIG.COLUMNS.BATCH
        ];
        
        return requiredFields.every(field => {
            const value = student[field];
            return value !== undefined && value !== null && value.toString().trim() !== '';
        });
    },
    
    validateResultData(result) {
        if (!result) return false;
        
        const requiredFields = [
            CONFIG.COLUMNS.ROLL_NO,
            CONFIG.COLUMNS.PERCENTAGE,
            CONFIG.COLUMNS.TEST_NAME
        ];
        
        return requiredFields.every(field => {
            const value = result[field];
            return value !== undefined && value !== null && value.toString().trim() !== '';
        });
    }
};
// DEBUG: Add this to the end of your config.js file
console.log('=== CONFIG.JS LOADED ===');
console.log('Admin session key:', CONFIG.ADMIN_SESSION_KEY);

// Test the validateAdminSession function
console.log('Testing session validation...');
const testSession = localStorage.getItem(CONFIG.ADMIN_SESSION_KEY);
console.log('Session in localStorage:', testSession);

if (testSession) {
    try {
        const parsed = JSON.parse(testSession);
        console.log('Parsed session:', parsed);
        console.log('Session valid?', UTILS.validateAdminSession());
    } catch (e) {
        console.log('Failed to parse session:', e);
    }
}