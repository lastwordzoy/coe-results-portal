// charts.js - Fixed chart functions for COE Portal
console.log('Charts module loaded');

// Destroy existing chart if it exists (FIXED)
function destroyChart(chart) {
    try {
        if (chart && typeof chart.destroy === 'function') {
            chart.destroy();
        }
    } catch (error) {
        console.warn('Error destroying chart:', error);
    }
}

// Create Score Distribution Chart
function createScoreDistributionChart(ctx, scoreDistribution) {
    try {
        // Destroy existing chart if any
        if (window.scoreDistributionChart) {
            destroyChart(window.scoreDistributionChart);
        }
        
        window.scoreDistributionChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: [
                    `Excellent (${CONFIG.THRESHOLDS.EXCELLENT}%+)`,
                    `Good (${CONFIG.THRESHOLDS.GOOD}-${CONFIG.THRESHOLDS.EXCELLENT-1}%)`,
                    `Average (${CONFIG.THRESHOLDS.AVERAGE}-${CONFIG.THRESHOLDS.GOOD-1}%)`,
                    `Needs Improvement (<${CONFIG.THRESHOLDS.AVERAGE}%)`
                ],
                datasets: [{
                    data: [
                        scoreDistribution.excellent || 0,
                        scoreDistribution.good || 0,
                        scoreDistribution.average || 0,
                        scoreDistribution.needImprovement || 0
                    ],
                    backgroundColor: ['#43a047', '#4fc3f7', '#ffb74d', '#e57373'],
                    borderWidth: 1,
                    hoverOffset: 15
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                                return `${label}: ${value} students (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        return window.scoreDistributionChart;
    } catch (error) {
        console.error('Error creating distribution chart:', error);
        return null;
    }
}

// Create Batch Comparison Chart
function createBatchComparisonChart(ctx, mpcData, bipcData) {
    try {
        // Destroy existing chart if any
        if (window.batchComparisonChart) {
            destroyChart(window.batchComparisonChart);
        }
        
        window.batchComparisonChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['MPC Stream', 'BiPC Stream'],
                datasets: [
                    {
                        label: 'Average Score',
                        data: [mpcData.avg || 0, bipcData.avg || 0],
                        backgroundColor: ['#667eea', '#f093fb'],
                        borderColor: ['#5568d4', '#d47fd1'],
                        borderWidth: 2
                    },
                    {
                        label: 'Top Score',
                        data: [mpcData.top || 0, bipcData.top || 0],
                        backgroundColor: ['#4a5fc1', '#c86bc6'],
                        borderColor: ['#3a4fa1', '#b85bb6'],
                        borderWidth: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        },
                        title: {
                            display: true,
                            text: 'Percentage'
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.raw}%`;
                            }
                        }
                    }
                }
            }
        });
        
        return window.batchComparisonChart;
    } catch (error) {
        console.error('Error creating batch comparison chart:', error);
        return null;
    }
}

// Create Monthly Trend Chart
function createMonthlyTrendChart(ctx, monthlyData) {
    try {
        const months = Object.keys(monthlyData || {}).sort();
        if (months.length === 0) return null;
        
        const averages = months.map(month => monthlyData[month].avg || 0);
        
        // Destroy existing chart if any
        if (window.monthlyTrendChart) {
            destroyChart(window.monthlyTrendChart);
        }
        
        window.monthlyTrendChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: months,
                datasets: [{
                    label: 'Average Performance',
                    data: averages,
                    borderColor: '#1a237e',
                    backgroundColor: 'rgba(26, 35, 126, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#1a237e',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        min: function() {
                            const min = Math.min(...averages);
                            return Math.max(0, min - 10);
                        },
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        },
                        title: {
                            display: true,
                            text: 'Average Score'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Month'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `Average: ${context.raw}%`;
                            }
                        }
                    }
                }
            }
        });
        
        return window.monthlyTrendChart;
    } catch (error) {
        console.error('Error creating trend chart:', error);
        return null;
    }
}

// Create Score Trend Chart for individual student
function createScoreTrendChart(ctx, labels, data, options = {}) {
    try {
        return new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: options.label || 'Score',
                    data: data,
                    borderColor: options.borderColor || '#1a237e',
                    backgroundColor: options.backgroundColor || 'rgba(26, 35, 126, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: options.max || 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error creating score trend chart:', error);
        return null;
    }
}

// Create specific dashboard charts (FIXED)
function createDashboardCharts(data, results) {
    console.log('Creating dashboard charts...');
    
    try {
        // Create batch comparison chart if canvas exists
        const batchCtx = document.getElementById('batchComparisonChart');
        if (batchCtx) {
            const mpcAvg = data.mpc.scores.length > 0 ? 
                (data.mpc.scores.reduce((a, b) => a + b, 0) / data.mpc.scores.length).toFixed(1) : 0;
            const bipcAvg = data.bipc.scores.length > 0 ? 
                (data.bipc.scores.reduce((a, b) => a + b, 0) / data.bipc.scores.length).toFixed(1) : 0;
            const mpcTop = data.mpc.scores.length > 0 ? Math.max(...data.mpc.scores).toFixed(1) : 0;
            const bipcTop = data.bipc.scores.length > 0 ? Math.max(...data.bipc.scores).toFixed(1) : 0;
            
            createBatchComparisonChart(
                batchCtx.getContext('2d'),
                { avg: parseFloat(mpcAvg) || 0, top: parseFloat(mpcTop) || 0 },
                { avg: parseFloat(bipcAvg) || 0, top: parseFloat(bipcTop) || 0 }
            );
        }
        
        // Create score distribution chart if canvas exists
        const distributionCtx = document.getElementById('scoreDistributionChart');
        if (distributionCtx) {
            createScoreDistributionChart(
                distributionCtx.getContext('2d'),
                data.scoreDistribution || {
                    excellent: 0,
                    good: 0,
                    average: 0,
                    needImprovement: 0
                }
            );
        }
        
        // Create monthly trend chart if canvas exists
        const monthlyCtx = document.getElementById('monthlyTrendChart');
        if (monthlyCtx && results && results.length > 0) {
            // Group results by month
            const monthlyData = {};
            
            results.forEach(result => {
                const dateStr = UTILS.getColumn(result, CONFIG.COLUMNS.DATE);
                if (dateStr) {
                    try {
                        const date = new Date(dateStr);
                        if (!isNaN(date.getTime())) {
                            const monthYear = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
                            const score = UTILS.parsePercentage(UTILS.getColumn(result, CONFIG.COLUMNS.PERCENTAGE));
                            
                            if (!monthlyData[monthYear]) {
                                monthlyData[monthYear] = { total: 0, count: 0 };
                            }
                            if (score > 0) {
                                monthlyData[monthYear].total += score;
                                monthlyData[monthYear].count++;
                            }
                        }
                    } catch (e) {
                        console.warn('Invalid date format:', dateStr);
                    }
                }
            });
            
            // Calculate averages
            Object.keys(monthlyData).forEach(month => {
                if (monthlyData[month].count > 0) {
                    monthlyData[month].avg = (monthlyData[month].total / monthlyData[month].count).toFixed(1);
                } else {
                    monthlyData[month].avg = 0;
                }
            });
            
            if (Object.keys(monthlyData).length > 0) {
                createMonthlyTrendChart(
                    monthlyCtx.getContext('2d'),
                    monthlyData
                );
            }
        }
        
        console.log('Dashboard charts created successfully');
    } catch (error) {
        console.error('Error creating dashboard charts:', error);
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('Charts.js initialized - Fixed version');
});