// main.js - Complete with all required functions
console.log('Main.js loaded');

// Global student map for quick lookup
let studentMap = {};

// Search students by term
function searchStudents(students, searchTerm) {
    if (!searchTerm.trim()) return students;
    
    const term = searchTerm.toLowerCase().trim();
    return students.filter(student => {
        const rollNo = UTILS.getColumn(student, CONFIG.COLUMNS.ROLL_NO);
        const name = UTILS.getColumn(student, CONFIG.COLUMNS.STUDENT_NAME) || '';
        const batch = UTILS.getColumn(student, CONFIG.COLUMNS.BATCH) || '';
        
        return rollNo.toLowerCase().includes(term) ||
               name.toLowerCase().includes(term) ||
               batch.toLowerCase().includes(term);
    });
}

// Load students from Google Sheets
async function loadStudents() {
    try {
        console.log('Loading students...');
        const response = await fetch(CONFIG.SHEET_URLS.STUDENTS);
        
        if (!response.ok) {
            throw new Error('Failed to load students');
        }
        
        const students = await response.json();
        
        // Create student map for quick lookup
        students.forEach(student => {
            const rollNo = UTILS.getColumn(student, CONFIG.COLUMNS.ROLL_NO);
            if (rollNo) {
                studentMap[rollNo] = student;
            }
        });
        
        console.log(`Loaded ${students.length} students`);
        return students;
    } catch (error) {
        console.error('Error loading students:', error);
        return [];
    }
}

// Load results from Google Sheets
async function loadResults() {
    try {
        console.log('Loading results...');
        const response = await fetch(CONFIG.SHEET_URLS.RESULTS);
        
        if (!response.ok) {
            throw new Error('Failed to load results');
        }
        
        const results = await response.json();
        console.log(`Loaded ${results.length} results`);
        return results;
    } catch (error) {
        console.error('Error loading results:', error);
        return [];
    }
}

// Load archives from Google Sheets
async function loadArchives() {
    try {
        console.log('Loading archives...');
        const response = await fetch(CONFIG.SHEET_URLS.ARCHIVES);
        
        if (!response.ok) {
            throw new Error('Failed to load archives');
        }
        
        const archives = await response.json();
        console.log(`Loaded ${archives.length} archives`);
        return archives;
    } catch (error) {
        console.error('Error loading archives:', error);
        return [];
    }
}

// Load attendance (placeholder)
async function loadAttendance() {
    try {
        console.log('Loading attendance...');
        // This would fetch from a different sheet/tab
        return [];
    } catch (error) {
        console.error('Error loading attendance:', error);
        return [];
    }
}

// Load all data for dashboard
async function loadAllData() {
    try {
        console.log('Loading all data...');
        const [students, results] = await Promise.all([
            loadStudents(),
            loadResults()
        ]);
        
        return { students, results };
    } catch (error) {
        console.error('Error loading all data:', error);
        return { students: [], results: [] };
    }
}

// Load all admin data
async function loadAllAdminData() {
    try {
        console.log('Loading all admin data...');
        const [students, results, attendance] = await Promise.all([
            loadStudents(),
            loadResults(),
            loadAttendance()
        ]);
        
        return { students, results, attendance };
    } catch (error) {
        console.error('Error loading admin data:', error);
        return { students: [], results: [], attendance: [] };
    }
}

// Handle data load errors
function handleDataLoadError(elementId, errorType = 'NETWORK') {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '';
        const errorMessage = UTILS.createErrorMessage(CONFIG.ERRORS[errorType]);
        element.appendChild(errorMessage);
    }
}

// Show data load error
function showDataLoadError() {
    const heroStats = document.getElementById('heroStats');
    if (heroStats) {
        heroStats.innerHTML = '';
        const errorMessage = UTILS.createErrorMessage(CONFIG.ERRORS.NETWORK);
        heroStats.appendChild(errorMessage);
    }
}

// Process batch data for charts with proper error handling
function processBatchData(students, results) {
    console.log('Processing batch data...');
    
    const batchData = {
        mpc: { students: [], scores: [] },
        bipc: { students: [], scores: [] },
        scoreDistribution: {
            excellent: 0,
            good: 0,
            average: 0,
            needImprovement: 0
        }
    };
    
    // Organize students by batch
    students.forEach(student => {
        const batch = UTILS.getColumn(student, CONFIG.COLUMNS.BATCH);
        if (batch && batch.includes('MPC')) {
            batchData.mpc.students.push(student);
        } else if (batch && batch.includes('BiPC')) {
            batchData.bipc.students.push(student);
        }
    });
    
    // Use student map for O(1) lookups
    if (results && results.length > 0) {
        results.forEach(result => {
            const rollNo = UTILS.getColumn(result, CONFIG.COLUMNS.ROLL_NO);
            const student = studentMap[rollNo];
            
            if (student) {
                const batch = UTILS.getColumn(student, CONFIG.COLUMNS.BATCH);
                const percentageStr = UTILS.getColumn(result, CONFIG.COLUMNS.PERCENTAGE);
                const score = UTILS.parsePercentage(percentageStr);
                
                if (score > 0) {
                    if (batch && batch.includes('MPC')) {
                        batchData.mpc.scores.push(score);
                    } else if (batch && batch.includes('BiPC')) {
                        batchData.bipc.scores.push(score);
                    }
                    
                    // Update score distribution
                    if (score >= CONFIG.THRESHOLDS.EXCELLENT) {
                        batchData.scoreDistribution.excellent++;
                    } else if (score >= CONFIG.THRESHOLDS.GOOD) {
                        batchData.scoreDistribution.good++;
                    } else if (score >= CONFIG.THRESHOLDS.AVERAGE) {
                        batchData.scoreDistribution.average++;
                    } else {
                        batchData.scoreDistribution.needImprovement++;
                    }
                }
            }
        });
    }
    
    // Handle empty data scenarios
    if (batchData.mpc.scores.length === 0 && batchData.bipc.scores.length === 0) {
        console.warn('No valid scores found in results');
        // Add some dummy data for charts to work
        if (results && results.length > 0) {
            // Extract scores from all results for distribution
            results.forEach(result => {
                const percentageStr = UTILS.getColumn(result, CONFIG.COLUMNS.PERCENTAGE);
                const score = UTILS.parsePercentage(percentageStr);
                
                if (score > 0) {
                    // Update score distribution only
                    if (score >= CONFIG.THRESHOLDS.EXCELLENT) {
                        batchData.scoreDistribution.excellent++;
                    } else if (score >= CONFIG.THRESHOLDS.GOOD) {
                        batchData.scoreDistribution.good++;
                    } else if (score >= CONFIG.THRESHOLDS.AVERAGE) {
                        batchData.scoreDistribution.average++;
                    } else {
                        batchData.scoreDistribution.needImprovement++;
                    }
                }
            });
        }
    }
    
    console.log('Batch data processed:', {
        mpc: { students: batchData.mpc.students.length, scores: batchData.mpc.scores.length },
        bipc: { students: batchData.bipc.students.length, scores: batchData.bipc.scores.length },
        scoreDistribution: batchData.scoreDistribution
    });
    
    return batchData;
}